import 'dart:async';

import 'package:flutter/material.dart';

import '../services/firestore_service.dart' show GameActionException;
import '../services/server_clock.dart';
import '../theme/conquera_theme.dart';

/// The insurgent's control panel, shown at the top of the map while hiding in
/// a territory: who the host is, a countdown to the overthrow, the overthrow
/// button (greyed until the countdown ends) and a build button while the
/// hideout has no building.
class InsurgencyPanel extends StatefulWidget {
  final String territoryName;
  final String? hostName;
  final Color? hostColor;

  /// When the overthrow unlocks (null = not known yet).
  final DateTime? readyAt;

  /// Label of the building in the hideout, or null if there is none.
  final String? buildingLabel;

  final Future<void> Function() onOverthrow;
  final VoidCallback onBuild;

  const InsurgencyPanel({
    super.key,
    required this.territoryName,
    required this.hostName,
    required this.hostColor,
    required this.readyAt,
    required this.buildingLabel,
    required this.onOverthrow,
    required this.onBuild,
  });

  @override
  State<InsurgencyPanel> createState() => _InsurgencyPanelState();
}

class _InsurgencyPanelState extends State<InsurgencyPanel> {
  Timer? _tick;
  bool _busy = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _tick = Timer.periodic(
      const Duration(seconds: 1),
      (_) => mounted ? setState(() {}) : null,
    );
  }

  @override
  void dispose() {
    _tick?.cancel();
    super.dispose();
  }

  Duration? get _left {
    final at = widget.readyAt;
    if (at == null) return null;
    final d = at.difference(ServerClock.now());
    return d.isNegative ? Duration.zero : d;
  }

  String _format(Duration d) {
    String two(int v) => v.toString().padLeft(2, '0');
    return '${d.inHours}:${two(d.inMinutes.remainder(60))}:'
        '${two(d.inSeconds.remainder(60))}';
  }

  Future<void> _overthrow() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: ConqueraColors.surface,
        surfaceTintColor: Colors.transparent,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(8),
          side: BorderSide(color: ConqueraColors.divider),
        ),
        title: Text('Overthrow ${widget.hostName ?? 'the owner'}?',
            style: ConqueraText.name),
        content: Text(
          '${widget.territoryName} becomes yours. The owner is told who '
          'did it and it appears in the news.',
          style: ConqueraText.value,
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: const Text('Cancel'),
          ),
          OutlinedButton(
            onPressed: () => Navigator.of(context).pop(true),
            style: OutlinedButton.styleFrom(
              foregroundColor: ConqueraColors.danger,
              side: BorderSide(color: ConqueraColors.danger),
            ),
            child: const Text('Overthrow'),
          ),
        ],
      ),
    );
    if (ok != true || !mounted) return;
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      await widget.onOverthrow();
    } on GameActionException catch (e) {
      if (mounted) setState(() => _error = e.message);
    } catch (_) {
      if (mounted) setState(() => _error = 'Something went wrong. Try again.');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final left = _left;
    final ready = left != null && left == Duration.zero;
    final hostColor = widget.hostColor ?? ConqueraColors.muted;
    return DecoratedBox(
          decoration: BoxDecoration(
            color: ConqueraColors.surface,
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: ConqueraColors.danger, width: 1.5),
          ),
          child: Padding(
            padding: const EdgeInsets.all(ConqueraSpace.md),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Row(
                  children: [
                    Icon(Icons.visibility_off,
                        size: 15, color: ConqueraColors.danger),
                    const SizedBox(width: 6),
                    Text(
                      'INSURGENT · HIDDEN',
                      style: ConqueraText.label.copyWith(
                        color: ConqueraColors.danger,
                        fontWeight: FontWeight.w700,
                        letterSpacing: 1.4,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: ConqueraSpace.xs),
                Text.rich(
                  TextSpan(
                    style: ConqueraText.value.copyWith(fontSize: 14.5),
                    children: [
                      TextSpan(
                        text: widget.territoryName,
                        style: const TextStyle(fontWeight: FontWeight.w700),
                      ),
                      const TextSpan(text: ' · held by '),
                      TextSpan(
                        text: widget.hostName ?? 'Unknown player',
                        style: TextStyle(
                          color: hostColor,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      if (widget.buildingLabel != null)
                        TextSpan(text: ' · ${widget.buildingLabel}'),
                    ],
                  ),
                ),
                const SizedBox(height: ConqueraSpace.sm),
                Row(
                  children: [
                    Expanded(
                      child: SizedBox(
                        height: 42,
                        child: FilledButton(
                          onPressed: ready && !_busy ? _overthrow : null,
                          style: FilledButton.styleFrom(
                            backgroundColor: ConqueraColors.danger,
                          ),
                          child: _busy
                              ? const SizedBox(
                                  width: 18,
                                  height: 18,
                                  child: CircularProgressIndicator(
                                    strokeWidth: 2,
                                  ),
                                )
                              : Text(
                                  ready
                                      ? 'Overthrow'
                                      : left == null
                                          ? 'Overthrow'
                                          : 'Overthrow in ${_format(left)}',
                                ),
                        ),
                      ),
                    ),
                    // The Build button goes away once there is a building.
                    if (widget.buildingLabel == null) ...[
                      const SizedBox(width: ConqueraSpace.sm),
                      SizedBox(
                        height: 42,
                        child: OutlinedButton.icon(
                          onPressed: _busy ? null : widget.onBuild,
                          icon: const Icon(Icons.construction, size: 18),
                          label: const Text('Build'),
                        ),
                      ),
                    ],
                  ],
                ),
                if (_error != null) ...[
                  const SizedBox(height: ConqueraSpace.sm),
                  Text(
                    _error!,
                    style: ConqueraText.label.copyWith(
                      color: ConqueraColors.danger,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ],
            ),
          ),
    );
  }
}
