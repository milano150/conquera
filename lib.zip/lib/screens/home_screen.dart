import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

import '../services/firestore_service.dart';
import '../theme/conquera_theme.dart';
import '../widgets/blur_route.dart';
import '../widgets/conquera_text_field.dart';
import 'join_screen.dart';
import 'map_screen.dart';

/// The first screen: the title and a box for the id of a world. Worlds are
/// created by hand in the database, so a world that doesn't exist is just
/// an error here.
///
/// A returning player (they already picked a name and color in that world)
/// goes straight to the map; a new one goes to [JoinScreen].
class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final TextEditingController _worldId = TextEditingController();
  final FirestoreService _service = FirestoreService();
  bool _busy = false;
  String? _error;

  @override
  void dispose() {
    _worldId.dispose();
    super.dispose();
  }

  Future<void> _enter() async {
    final worldId = _worldId.text.trim();
    if (worldId.isEmpty || _busy) return;

    setState(() {
      _busy = true;
      _error = null;
    });

    try {
      final uid = FirebaseAuth.instance.currentUser!.uid;

      if (!await _service.worldExists(worldId)) {
        if (mounted) setState(() => _error = 'No world with that id.');
        return;
      }

      final joined = await _service.playerExists(gameId: worldId, uid: uid);
      if (joined) {
        try {
          await _service.reconcileIncome(gameId: worldId, uid: uid);
        } catch (e) {
          debugPrint('Income reconcile failed: $e');
        }
      }
      if (!mounted) return;

      await Navigator.of(context).push(
        BlurRoute<void>(
          builder: (_) => joined
              ? MapScreen(gameId: worldId)
              : JoinScreen(gameId: worldId),
        ),
      );
    } catch (e) {
      debugPrint('Entering world failed: $e');
      if (mounted) setState(() => _error = 'Could not reach the server.');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(ConqueraSpace.lg),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 320),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    'conquera.beta',
                    textAlign: TextAlign.center,
                    style: ConqueraText.title.copyWith(
                      fontSize: 44,
                      letterSpacing: -0.5,
                    ),
                  ),
                  const SizedBox(height: ConqueraSpace.xl),
                  ConqueraTextField(
                    controller: _worldId,
                    hint: 'enter world_id',
                    enabled: !_busy,
                    autofocus: true,
                    textInputAction: TextInputAction.go,
                    onChanged: (_) {
                      if (_error != null) setState(() => _error = null);
                    },
                    onSubmitted: (_) => _enter(),
                  ),
                  const SizedBox(height: ConqueraSpace.md),
                  SizedBox(
                    height: 18,
                    child: _error == null
                        ? null
                        : Text(
                            _error!,
                            textAlign: TextAlign.center,
                            style: ConqueraText.label.copyWith(
                              color: ConqueraColors.danger,
                            ),
                          ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}