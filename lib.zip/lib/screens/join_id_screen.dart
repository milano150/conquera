import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

import '../config/dev_session.dart';
import '../models/player_state.dart';
import '../services/firestore_service.dart';
import '../services/world_entry.dart';
import '../theme/conquera_theme.dart';
import '../widgets/conquera_text_field.dart';

/// Third screen (from "Join with ID"): type the id of a world and enter it.
/// Worlds are created by hand in the database, so a world that doesn't exist
/// is just an error here.
class JoinIdScreen extends StatefulWidget {
  const JoinIdScreen({super.key});

  @override
  State<JoinIdScreen> createState() => _JoinIdScreenState();
}

class _JoinIdScreenState extends State<JoinIdScreen> {
  final TextEditingController _worldId = TextEditingController();
  final FirestoreService _service = FirestoreService();
  bool _busy = false;
  String? _error;

  @override
  void dispose() {
    _worldId.dispose();
    super.dispose();
  }

  Future<void> _enter() async {
    if (_busy) return;
    final worldId = _worldId.text.trim();
    if (worldId.isEmpty) return;
    setState(() {
      _busy = true;
      _error = null;
    });
    final error = await WorldEntry.enter(context, _service, worldId);
    if (mounted) {
      setState(() {
        _busy = false;
        _error = error;
      });
    }
  }

  /// BETA: pick any player that exists in the entered world and act as them
  /// from now on, then enter the world.
  Future<void> _logInAsPlayer() async {
    final worldId = _worldId.text.trim();
    if (worldId.isEmpty) {
      setState(() => _error = 'Enter a world id first.');
      return;
    }
    if (_busy) return;
    setState(() {
      _busy = true;
      _error = null;
    });
    List<PlayerState> players;
    try {
      if (!await _service.worldExists(worldId)) {
        if (mounted) setState(() => _error = 'No world with that id.');
        return;
      }
      players = await _service.listPlayers(gameId: worldId);
    } catch (e) {
      debugPrint('Listing players failed: $e');
      if (mounted) setState(() => _error = 'Could not reach the server.');
      return;
    } finally {
      if (mounted) setState(() => _busy = false);
    }
    if (!mounted) return;

    final picked = await showModalBottomSheet<_PlayerChoice>(
      context: context,
      backgroundColor: ConqueraColors.surface,
      showDragHandle: true,
      isScrollControlled: true,
      builder: (_) => _PlayerPicker(
        players: players,
        currentUid: DevSession.isImpersonating ? DevSession.uid : null,
      ),
    );
    if (picked == null || !mounted) return;
    if (picked.uid == null) {
      DevSession.reset();
    } else {
      DevSession.actAs(picked.uid!);
    }
    await _enter();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: ConqueraColors.land,
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(
                ConqueraSpace.sm,
                ConqueraSpace.sm,
                ConqueraSpace.md,
                ConqueraSpace.sm,
              ),
              child: Row(
                children: [
                  IconButton(
                    onPressed: () => Navigator.of(context).pop(),
                    icon: const Icon(Icons.arrow_back, size: 20),
                    color: ConqueraColors.ink,
                  ),
                  Text(
                    'Join with ID',
                    style: ConqueraText.title.copyWith(fontSize: 22),
                  ),
                ],
              ),
            ),
            Divider(height: 1, color: ConqueraColors.divider),
            Expanded(
              child: Center(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.all(ConqueraSpace.lg),
                  child: ConstrainedBox(
                    constraints: const BoxConstraints(maxWidth: 320),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        ConqueraTextField(
                          controller: _worldId,
                          hint: 'enter world_id',
                          autofocus: true,
                          textInputAction: TextInputAction.go,
                          onChanged: (_) {
                            if (_error != null) setState(() => _error = null);
                          },
                          onSubmitted: (_) => _enter(),
                        ),
                        const SizedBox(height: ConqueraSpace.md),
                        OutlinedButton(
                          // Stays as it is while loading; _enter ignores
                          // extra taps.
                          onPressed: _enter,
                          style: OutlinedButton.styleFrom(
                            minimumSize: const Size.fromHeight(46),
                          ),
                          child: const Text('Join world'),
                        ),
                        const SizedBox(height: ConqueraSpace.sm),
                        TextButton(
                          onPressed: _busy ? null : _logInAsPlayer,
                          child: const Text('Beta: log in as any player'),
                        ),
                        const SizedBox(height: ConqueraSpace.md),
                        SizedBox(
                          height: 18,
                          child: _error == null
                              ? null
                              : Text(
                                  _error!,
                                  textAlign: TextAlign.center,
                                  style: ConqueraText.label.copyWith(
                                    color: ConqueraColors.danger,
                                  ),
                                ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Result of the beta picker: a player's uid, or null = use my own account.
class _PlayerChoice {
  final String? uid;
  const _PlayerChoice(this.uid);
}

/// BETA: bottom sheet listing every player of a world.
class _PlayerPicker extends StatelessWidget {
  final List<PlayerState> players;

  /// The player this device is currently acting as (null = its own account).
  final String? currentUid;

  const _PlayerPicker({required this.players, required this.currentUid});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: ConstrainedBox(
        constraints: BoxConstraints(
          maxHeight: MediaQuery.of(context).size.height * 0.7,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(
                ConqueraSpace.lg,
                0,
                ConqueraSpace.lg,
                ConqueraSpace.sm,
              ),
              child: Text('Log in as', style: ConqueraText.title),
            ),
            Flexible(
              child: ListView(
                shrinkWrap: true,
                children: [
                  ListTile(
                    title: Text('My own account', style: ConqueraText.value),
                    subtitle: Text(
                      'Use this device\'s account',
                      style: ConqueraText.label,
                    ),
                    selected: currentUid == null,
                    onTap: () =>
                        Navigator.of(context).pop(const _PlayerChoice(null)),
                  ),
                  const Divider(height: 1),
                  if (players.isEmpty)
                    Padding(
                      padding: const EdgeInsets.all(ConqueraSpace.lg),
                      child: Text(
                        'No players in this world yet.',
                        style: ConqueraText.label,
                      ),
                    ),
                  for (final p in players)
                    ListTile(
                      leading: CircleAvatar(radius: 8, backgroundColor: p.color),
                      title: Text(p.displayName, style: ConqueraText.value),
                      selected: p.uid == currentUid,
                      onTap: () =>
                          Navigator.of(context).pop(_PlayerChoice(p.uid)),
                    ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}