import 'package:flutter/material.dart';

import '../config/dev_session.dart';
import '../config/recent_worlds.dart';
import '../models/player_state.dart';
import '../services/firestore_service.dart';
import '../services/server_clock.dart';
import '../services/world_entry.dart';
import '../theme/conquera_theme.dart';
import '../widgets/light_screens_observer.dart';
import '../widgets/slide_route.dart';
import 'join_id_screen.dart';

/// What a world card shows, read live from the world.
class _WorldInfo {
  final bool exists;
  final bool failed;
  final PlayerState? player;

  const _WorldInfo({this.exists = true, this.failed = false, this.player});
}

/// Second screen (after Play): the worlds this device has joined, most recent
/// first, with the player's name and color in each and a few stats. A button
/// on top joins another world by id.
class WorldsScreen extends StatefulWidget {
  const WorldsScreen({super.key});

  @override
  State<WorldsScreen> createState() => _WorldsScreenState();
}

class _WorldsScreenState extends State<WorldsScreen> {
  final FirestoreService _service = FirestoreService();

  List<String>? _ids;
  final Map<String, Future<_WorldInfo>> _info = {};
  String? _enteringId;
  String? _error;

  @override
  void initState() {
    super.initState();
    _reload();
  }

  Future<void> _reload() async {
    final ids = await RecentWorlds.load();
    if (!mounted) return;
    setState(() {
      _ids = ids;
      _info
        ..clear()
        ..addEntries([for (final id in ids) MapEntry(id, _fetch(id))]);
    });
  }

  Future<_WorldInfo> _fetch(String id) async {
    try {
      if (!await _service.worldExists(id)) {
        return const _WorldInfo(exists: false);
      }
      final player = await _service.fetchPlayer(
        gameId: id,
        uid: DevSession.uid,
      );
      return _WorldInfo(player: player);
    } catch (_) {
      return const _WorldInfo(failed: true);
    }
  }

  Future<void> _open(String id) async {
    if (_enteringId != null) return;
    setState(() {
      _enteringId = id;
      _error = null;
    });
    final error = await WorldEntry.enter(context, _service, id);
    if (!mounted) return;
    setState(() {
      _enteringId = null;
      _error = error;
    });
    await _reload();
  }

  Future<void> _remove(String id) async {
    await RecentWorlds.remove(id);
    await _reload();
  }

  Future<void> _joinWithId() async {
    await Navigator.of(context).push(
      SlideRoute<void>(
        settings: const RouteSettings(name: kLightRouteName),
        builder: (_) => const JoinIdScreen(),
      ),
    );
    if (mounted) await _reload();
  }

  static String _n(num v) {
    final digits = v.floor().toString();
    final b = StringBuffer();
    for (var i = 0; i < digits.length; i++) {
      if (i > 0 && (digits.length - i) % 3 == 0) b.write(',');
      b.write(digits[i]);
    }
    return b.toString();
  }

  @override
  Widget build(BuildContext context) {
    final ids = _ids;
    return Scaffold(
      backgroundColor: ConqueraColors.land,
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(
                ConqueraSpace.sm,
                ConqueraSpace.sm,
                ConqueraSpace.md,
                ConqueraSpace.sm,
              ),
              child: Row(
                children: [
                  IconButton(
                    onPressed: () => Navigator.of(context).pop(),
                    icon: const Icon(Icons.arrow_back, size: 20),
                    color: ConqueraColors.ink,
                  ),
                  Expanded(
                    child: Text(
                      'Your worlds',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: ConqueraText.title.copyWith(fontSize: 22),
                    ),
                  ),
                  OutlinedButton(
                    onPressed: _joinWithId,
                    child: const Text('Join with ID'),
                  ),
                ],
              ),
            ),
            Divider(height: 1, color: ConqueraColors.divider),
            if (_error != null)
              Padding(
                padding: const EdgeInsets.fromLTRB(
                  ConqueraSpace.md,
                  ConqueraSpace.sm,
                  ConqueraSpace.md,
                  0,
                ),
                child: Text(
                  _error!,
                  textAlign: TextAlign.center,
                  style: ConqueraText.label.copyWith(
                    color: ConqueraColors.danger,
                  ),
                ),
              ),
            Expanded(
              child: ids == null
                  ? const SizedBox.shrink()
                  : ids.isEmpty
                      ? Center(
                          child: Padding(
                            padding: const EdgeInsets.all(ConqueraSpace.lg),
                            child: Text(
                              'No worlds yet.\nUse "Join with ID" to enter one.',
                              textAlign: TextAlign.center,
                              style: ConqueraText.label.copyWith(fontSize: 14),
                            ),
                          ),
                        )
                      : RefreshIndicator(
                          color: ConqueraColors.ink,
                          onRefresh: _reload,
                          child: Align(
                            alignment: Alignment.topCenter,
                            child: ConstrainedBox(
                              constraints:
                                  const BoxConstraints(maxWidth: 480),
                              child: ListView.separated(
                                physics:
                                    const AlwaysScrollableScrollPhysics(),
                                padding: const EdgeInsets.all(ConqueraSpace.md),
                                itemCount: ids.length,
                                separatorBuilder: (_, __) =>
                                    const SizedBox(height: ConqueraSpace.sm),
                                itemBuilder: (_, i) => _card(ids[i]),
                              ),
                            ),
                          ),
                        ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _card(String id) {
    return FutureBuilder<_WorldInfo>(
      future: _info[id],
      builder: (context, snap) {
        final info = snap.data;
        final player = info?.player;
        final dim = info != null && (!info.exists || player == null);
        return Material(
          color: ConqueraColors.surface,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(8),
            side: BorderSide(color: ConqueraColors.divider),
          ),
          clipBehavior: Clip.antiAlias,
          child: InkWell(
            onTap: info != null && !info.exists ? null : () => _open(id),
            child: Padding(
              padding: const EdgeInsets.all(ConqueraSpace.md),
              child: Row(
                children: [
                  _avatar(player),
                  const SizedBox(width: ConqueraSpace.md),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          id,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: ConqueraText.name.copyWith(
                            color: dim
                                ? ConqueraColors.muted
                                : ConqueraColors.ink,
                          ),
                        ),
                        const SizedBox(height: 4),
                        ..._details(info, player),
                      ],
                    ),
                  ),
                  if (_enteringId == id)
                    const SizedBox(
                      width: 18,
                      height: 18,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  else
                    IconButton(
                      tooltip: 'Remove from list',
                      onPressed: _enteringId == null ? () => _remove(id) : null,
                      icon: const Icon(Icons.close, size: 18),
                      color: ConqueraColors.muted,
                      visualDensity: VisualDensity.compact,
                    ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  /// The player's color with the first letter of their name.
  Widget _avatar(PlayerState? player) {
    final color = player?.color;
    final name = player?.displayName ?? '';
    final letter =
        name.isEmpty ? '?' : String.fromCharCode(name.runes.first).toUpperCase();
    final onColor = color == null
        ? ConqueraColors.muted
        : (color.computeLuminance() > 0.5 ? ConqueraColors.ink : Colors.white);
    return Container(
      width: 40,
      height: 40,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        color: color ?? ConqueraColors.divider.withAlpha(90),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Text(
        letter,
        style: ConqueraText.name.copyWith(color: onColor),
      ),
    );
  }

  List<Widget> _details(_WorldInfo? info, PlayerState? player) {
    if (info == null) {
      return [Text('Loading...', style: ConqueraText.label)];
    }
    if (!info.exists) {
      return [Text('This world no longer exists', style: ConqueraText.label)];
    }
    if (info.failed) {
      return [Text('Could not load', style: ConqueraText.label)];
    }
    if (player == null) {
      return [Text('Not joined yet', style: ConqueraText.label)];
    }
    final gold = player.goldAt(ServerClock.now());
    final perHour = player.goldRate * 3600;
    return [
      Text(
        player.displayName,
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
        style: ConqueraText.value.copyWith(color: player.color),
      ),
      const SizedBox(height: 3),
      Text(
        '${player.ownedCount} '
        '${player.ownedCount == 1 ? 'territory' : 'territories'}'
        '  ·  ${_n(gold)} gold  ·  +${_n(perHour)}/hr',
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
        style: ConqueraText.label,
      ),
    ];
  }
}