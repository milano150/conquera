import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../models/player_state.dart';
import '../models/province_state.dart';
import '../models/trade_offer.dart';
import '../services/firestore_service.dart' show GameActionException;
import '../services/server_clock.dart';
import '../services/trade_service.dart';
import '../theme/conquera_theme.dart';
import '../widgets/gold_amount.dart';

/// Trade gold for territories with other players. Two tabs: open offers
/// you can accept, and your own offers.
class TradeScreen extends StatefulWidget {
  final String gameId;
  final String? myUid;
  final ValueListenable<Map<String, PlayerState>> players;
  final ValueListenable<Map<String, ProvinceState>> provinces;

  /// province id -> country name.
  final Map<String, String> provinceNames;

  const TradeScreen({
    super.key,
    required this.gameId,
    required this.myUid,
    required this.players,
    required this.provinces,
    required this.provinceNames,
  });

  @override
  State<TradeScreen> createState() => _TradeScreenState();
}

class _Opt {
  final String id;
  final String name;
  const _Opt(this.id, this.name);
}

class _Draft {
  final TradeKind kind;
  final String provinceId;
  final int price;
  const _Draft(this.kind, this.provinceId, this.price);
}

class _TradeScreenState extends State<TradeScreen> {
  final TradeService _service = TradeService();
  StreamSubscription<List<TradeOffer>>? _sub;
  List<TradeOffer> _offers = const [];
  bool _mine = false;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    _sub = _service.watchOffers(gameId: widget.gameId).listen(
      (list) {
        if (mounted) setState(() => _offers = list);
      },
      onError: (_) {},
    );
  }

  @override
  void dispose() {
    _sub?.cancel();
    super.dispose();
  }

  String _name(String id) => widget.provinceNames[id] ?? id;

  void _toast(String message) {
    final m = ScaffoldMessenger.of(context);
    m.hideCurrentSnackBar();
    m.showSnackBar(SnackBar(content: Text(message)));
  }

  Future<void> _run(Future<void> Function() job, String done) async {
    if (_busy) return;
    setState(() => _busy = true);
    try {
      await job();
      if (mounted) _toast(done);
    } on GameActionException catch (e) {
      if (mounted) _toast(e.message);
    } catch (_) {
      if (mounted) _toast('Something went wrong. Try again.');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  /// An offer still makes sense: the territory is empty of buildings and
  /// belongs to the right player.
  bool _valid(TradeOffer o, Map<String, ProvinceState> provs) {
    final p = provs[o.provinceId];
    if (p == null || p.hasBuilding) return false;
    final owner = p.ownerId;
    return o.kind == TradeKind.sell
        ? owner == o.creatorId
        : owner != null && owner != o.creatorId;
  }

  List<_Opt> _options(
    String uid,
    Map<String, ProvinceState> provs,
    bool sell,
  ) {
    final owned = provs.values.where((p) => p.ownerId == uid).length;
    if (sell && owned <= 1) return const [];
    final list = [
      for (final p in provs.values)
        if (!p.hasBuilding &&
            p.ownerId != null &&
            (sell ? p.ownerId == uid : p.ownerId != uid))
          _Opt(p.id, _name(p.id)),
    ]..sort((a, b) => a.name.compareTo(b.name));
    return list;
  }

  Future<void> _newOffer(String uid, Map<String, ProvinceState> provs) async {
    final draft = await showModalBottomSheet<_Draft>(
      context: context,
      isScrollControlled: true,
      backgroundColor: ConqueraColors.surface,
      builder: (_) => _NewOfferSheet(
        sellOptions: _options(uid, provs, true),
        buyOptions: _options(uid, provs, false),
      ),
    );
    if (draft == null || !mounted) return;
    await _run(
      () => _service.createOffer(
        gameId: widget.gameId,
        uid: uid,
        kind: draft.kind,
        provinceId: draft.provinceId,
        price: draft.price,
      ),
      'Offer posted.',
    );
  }

  @override
  Widget build(BuildContext context) {
    final uid = widget.myUid;
    return Scaffold(
      backgroundColor: ConqueraColors.surface,
      appBar: AppBar(
        backgroundColor: ConqueraColors.surface,
        foregroundColor: ConqueraColors.ink,
        elevation: 0,
        scrolledUnderElevation: 0,
        title: Text('Trade', style: ConqueraText.title.copyWith(fontSize: 22)),
      ),
      body: uid == null
          ? Center(child: Text('Join the world to trade.', style: ConqueraText.label))
          : ValueListenableBuilder<Map<String, ProvinceState>>(
              valueListenable: widget.provinces,
              builder: (context, provs, _) => _body(uid, provs),
            ),
    );
  }

  Widget _body(String uid, Map<String, ProvinceState> provs) {
    final gold =
        widget.players.value[uid]?.goldAt(ServerClock.now()) ?? 0;
    final rows = _mine
        ? _offers.where((o) => o.creatorId == uid).toList()
        : _offers
            .where((o) =>
                o.creatorId != uid &&
                _valid(o, provs) &&
                (o.kind == TradeKind.sell || provs[o.provinceId]?.ownerId == uid))
            .toList();

    return Column(
      children: [
        _Balance(players: widget.players, uid: uid),
        Row(
          children: [
            const SizedBox(width: ConqueraSpace.md),
            _Tab(label: 'Offers', on: !_mine, onTap: () => setState(() => _mine = false)),
            const SizedBox(width: ConqueraSpace.md),
            _Tab(label: 'Mine', on: _mine, onTap: () => setState(() => _mine = true)),
          ],
        ),
        Divider(height: 1, color: ConqueraColors.divider),
        Expanded(
          child: rows.isEmpty
              ? Center(
                  child: Text(
                    _mine ? 'No offers of yours.' : 'No open offers.',
                    style: ConqueraText.label,
                  ),
                )
              : ListView.separated(
                  itemCount: rows.length,
                  separatorBuilder: (_, __) =>
                      Divider(height: 1, color: ConqueraColors.divider),
                  itemBuilder: (_, i) => _row(rows[i], uid, provs, gold),
                ),
        ),
        SafeArea(
          top: false,
          child: Padding(
            padding: const EdgeInsets.all(ConqueraSpace.md),
            child: SizedBox(
              width: double.infinity,
              child: OutlinedButton(
                onPressed: _busy ? null : () => _newOffer(uid, provs),
                child: const Text('New offer'),
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _row(
    TradeOffer o,
    String uid,
    Map<String, ProvinceState> provs,
    double gold,
  ) {
    final sell = o.kind == TradeKind.sell;
    final mine = o.creatorId == uid;
    final String sub;
    if (mine) {
      sub = _valid(o, provs)
          ? (sell ? 'You sell' : 'You want')
          : 'No longer valid';
    } else {
      sub = '${o.creatorName} ${sell ? 'sells' : 'wants'}';
    }
    final canAfford = !sell || gold >= o.price;

    final String action;
    final VoidCallback? onTap;
    if (mine) {
      action = 'Cancel';
      onTap = () => _run(
            () => _service.cancelOffer(
                gameId: widget.gameId, uid: uid, offerId: o.id),
            'Offer cancelled.',
          );
    } else {
      action = sell ? 'Buy' : 'Sell';
      onTap = canAfford
          ? () => _run(
                () => _service.acceptOffer(
                    gameId: widget.gameId, uid: uid, offerId: o.id),
                sell ? 'Territory bought.' : 'Territory sold.',
              )
          : null;
    }

    return Padding(
      padding: const EdgeInsets.symmetric(
        horizontal: ConqueraSpace.md,
        vertical: ConqueraSpace.sm,
      ),
      child: Row(
        children: [
          Container(
            width: 10,
            height: 10,
            decoration: BoxDecoration(
              color: _hex(o.creatorColor),
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(_name(o.provinceId), style: ConqueraText.name),
                const SizedBox(height: 2),
                Text(sub, style: ConqueraText.label),
              ],
            ),
          ),
          GoldAmount(
            o.price,
            style: ConqueraText.figure.copyWith(fontSize: 16),
            faded: !mine && !canAfford,
          ),
          const SizedBox(width: ConqueraSpace.sm),
          TextButton(
            onPressed: _busy ? null : onTap,
            child: Text(action),
          ),
        ],
      ),
    );
  }
}

Color _hex(String hex) {
  final v = int.tryParse(hex.replaceFirst('#', ''), radix: 16) ?? 0x457B9D;
  return Color(0xFF000000 | v);
}

class _Tab extends StatelessWidget {
  final String label;
  final bool on;
  final VoidCallback onTap;

  const _Tab({required this.label, required this.on, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 10),
        decoration: BoxDecoration(
          border: Border(
            bottom: BorderSide(
              color: on ? ConqueraColors.ink : Colors.transparent,
              width: 2,
            ),
          ),
        ),
        child: Text(
          label,
          style: ConqueraText.value.copyWith(
            color: on ? ConqueraColors.ink : ConqueraColors.muted,
          ),
        ),
      ),
    );
  }
}

/// Your gold, ticking live.
class _Balance extends StatefulWidget {
  final ValueListenable<Map<String, PlayerState>> players;
  final String uid;

  const _Balance({required this.players, required this.uid});

  @override
  State<_Balance> createState() => _BalanceState();
}

class _BalanceState extends State<_Balance> {
  Timer? _tick;

  @override
  void initState() {
    super.initState();
    _tick = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) setState(() {});
    });
  }

  @override
  void dispose() {
    _tick?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final gold =
        widget.players.value[widget.uid]?.goldAt(ServerClock.now()) ?? 0;
    return Padding(
      padding: const EdgeInsets.fromLTRB(
        ConqueraSpace.md,
        ConqueraSpace.sm,
        ConqueraSpace.md,
        ConqueraSpace.md,
      ),
      child: Row(
        children: [
          Text('Your gold', style: ConqueraText.label),
          const Spacer(),
          GoldAmount(gold.floor(), style: ConqueraText.figure, iconSize: 18),
        ],
      ),
    );
  }
}

class _NewOfferSheet extends StatefulWidget {
  final List<_Opt> sellOptions;
  final List<_Opt> buyOptions;

  const _NewOfferSheet({required this.sellOptions, required this.buyOptions});

  @override
  State<_NewOfferSheet> createState() => _NewOfferSheetState();
}

class _NewOfferSheetState extends State<_NewOfferSheet> {
  final TextEditingController _price = TextEditingController();
  TradeKind _kind = TradeKind.sell;
  String? _province;

  @override
  void dispose() {
    _price.dispose();
    super.dispose();
  }

  int get _amount => int.tryParse(_price.text) ?? 0;

  bool get _ready =>
      _province != null && _amount >= 1 && _amount <= TradeService.maxPrice;

  @override
  Widget build(BuildContext context) {
    final sell = _kind == TradeKind.sell;
    final opts = sell ? widget.sellOptions : widget.buyOptions;
    return Padding(
      padding: EdgeInsets.fromLTRB(
        ConqueraSpace.md,
        ConqueraSpace.md,
        ConqueraSpace.md,
        ConqueraSpace.md + MediaQuery.viewInsetsOf(context).bottom,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          SegmentedButton<TradeKind>(
            showSelectedIcon: false,
            segments: const [
              ButtonSegment(value: TradeKind.sell, label: Text('Sell')),
              ButtonSegment(value: TradeKind.buy, label: Text('Buy')),
            ],
            selected: {_kind},
            onSelectionChanged: (s) => setState(() {
              _kind = s.first;
              _province = null;
            }),
          ),
          const SizedBox(height: ConqueraSpace.md),
          DropdownMenu<String>(
            key: ValueKey(_kind),
            width: MediaQuery.sizeOf(context).width - 2 * ConqueraSpace.md,
            enableFilter: true,
            requestFocusOnTap: true,
            label: const Text('Territory'),
            dropdownMenuEntries: [
              for (final o in opts) DropdownMenuEntry(value: o.id, label: o.name),
            ],
            onSelected: (v) => setState(() => _province = v),
          ),
          const SizedBox(height: ConqueraSpace.md),
          TextField(
            controller: _price,
            keyboardType: TextInputType.number,
            inputFormatters: [
              FilteringTextInputFormatter.digitsOnly,
              LengthLimitingTextInputFormatter(7),
            ],
            decoration: const InputDecoration(labelText: 'Price in gold'),
            onChanged: (_) => setState(() {}),
          ),
          const SizedBox(height: ConqueraSpace.sm),
          Text(
            opts.isEmpty
                ? (sell
                    ? 'Nothing to sell: keep at least one territory, and buildings can\'t be traded.'
                    : 'No territories available to buy.')
                : (sell
                    ? 'Troops stay with the territory.'
                    : 'Pays only if the owner accepts.'),
            style: ConqueraText.label,
          ),
          const SizedBox(height: ConqueraSpace.md),
          OutlinedButton(
            onPressed: _ready
                ? () => Navigator.of(context)
                    .pop(_Draft(_kind, _province!, _amount))
                : null,
            child: const Text('Post offer'),
          ),
        ],
      ),
    );
  }
}