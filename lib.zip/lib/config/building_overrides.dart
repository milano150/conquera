// Per-territory tuning for buildings: how much a building earns and whether
// it may be built, territory by territory. Edit only this file to rebalance;
// nothing here is stored in Firestore.
//
// Lookup order for a (building, territory) pair:
//   1. [byBuilding]   - an exact territory rule
//   2. [byGroup]      - a rule shared by a set of territories
//   3. nothing found  - the building's defaults from game_rules.dart
//
// Territory ids are the ISO 3166-1 alpha-2 ids the SVG uses (see
// territories.txt). Building ids are the `id:` values in game_rules.dart
// (gold_mine, fishing_harbor, offshore_rig, market, ...).
import 'dart:math' show ln10, log;

import 'territory_types.dart';

class TerritoryRule {
  /// Multiplier on the building's income there (gold/sec and gold/sec per
  /// trading neighbor). 1 = normal, 2 = double, 0.5 = half.
  final double rate;

  /// false = this building can never be built here.
  /// true  = it can be built here even if its site rule (coastal, island)
  ///         would say no.
  /// null  = normal availability rules.
  final bool? allowed;

  const TerritoryRule({this.rate = 1, this.allowed});
}

class _Group {
  final Set<String> ids;
  final TerritoryRule rule;
  const _Group(this.ids, this.rule);
}

class BuildingOverrides {
  BuildingOverrides._();

  /// building id -> territory id -> rule.
  static final Map<String, Map<String, TerritoryRule>> byBuilding = {
    'gold_mine': _goldRules,
    'fishing_harbor': {
      'NO': TerritoryRule(rate: 1.5),
      'IS': TerritoryRule(rate: 1.5),
    },
    'offshore_rig': _rigRules,
  };

  // --- Offshore oil rigs ---------------------------------------------------
  // Rate comes from real crude oil production, in thousand barrels per day.
  // Islands missing from [_oilKbd] produce no (or negligible) crude and get
  // [_rigNoOil]. Tune the whole scale with the constants below.
  //
  // These are NATIONAL crude totals, not offshore-only (the UK is almost all
  // offshore; Indonesia, Bahrain and Cuba are mostly onshore).
  //
  // Sources: UK 2025 Energy Intelligence; Indonesia 2024-25 SKK Migas;
  // Bahrain, Trinidad & Tobago, Cuba, New Zealand, Philippines 2023 US EIA;
  // Papua New Guinea Worldometers; Barbados CIA World Factbook (2018 est.);
  // Falklands: Sea Lion FID Dec 2025, first oil 2028, ~50 kb/d peak.
  static const Map<String, double> _oilKbd = {
    'GB': 569,
    'ID': 580,
    'BH': 180,
    'TT': 54,
    'PG': 32,
    'CU': 30,
    'NZ': 7,
    'BB': 1,
    'PH': 0.9,
    'FK': 25, // not producing yet: half of the planned 50 kb/d peak
  };

  static const double _rigBase = 0.5;
  static const double _rigSlope = 0.9; // per factor of 10 in kb/d
  static const double _rigMin = 0.5;
  static const double _rigMax = 3;
  static const double _rigNoOil = 0.25;

  static double _rigRate(double kbd) {
    if (kbd <= 0) return _rigNoOil;
    final r = (_rigBase + _rigSlope * log(kbd) / ln10).clamp(_rigMin, _rigMax);
    return (r * 100).round() / 100;
  }

  static final Map<String, TerritoryRule> _rigRules = {
    for (final id in TerritoryTypes.islandArchipelagos)
      id: TerritoryRule(rate: _rigRate(_oilKbd[id] ?? 0)),
    for (final e in _oilKbd.entries)
      e.key: TerritoryRule(rate: _rigRate(e.value)),
  };

  // --- Gold mines ----------------------------------------------------------
  // Rate comes from real gold mine production, in tonnes per year. Territories
  // missing from [_goldT] have no (or unverified, small) production and get
  // the building's default in [defaultRate].
  //
  // Mixed vintages, newest available per country:
  //  * 2024 World Gold Council / Metals Focus: CN RU AU CA US GH MX ID PE UZ
  //    ML ZA BF KZ BR SD GN CO CI TZ PG
  //  * 2023 USGS: ZW CD AR TR CL KG PH SR EC EG GY MN NZ ET
  //  * 2020-21 Metals Focus: BO VE DO NE MR LR MG SN LA BG FI SE
  static const Map<String, double> _goldT = {
    'CN': 380, 'RU': 330, 'AU': 284, 'CA': 202, 'US': 158, 'GH': 141,
    'MX': 140, 'ID': 140, 'PE': 137, 'UZ': 129, 'ML': 100, 'ZA': 99,
    'BF': 94, 'KZ': 87, 'BR': 84, 'SD': 74, 'GN': 68, 'CO': 66, 'CI': 58,
    'TZ': 52, 'PG': 50, 'ZW': 46.6, 'BO': 45.7, 'CD': 44, 'AR': 41,
    'TR': 36.3, 'CL': 35.8, 'VE': 35, 'NE': 33.4, 'KG': 32, 'PH': 31,
    'SR': 18.3, 'DO': 25.5, 'MR': 21.8, 'LR': 19.9, 'EC': 18, 'SN': 17.1,
    'MG': 15.9, 'MN': 14.9, 'EG': 14.7, 'GY': 13.4, 'BG': 9.7, 'FI': 9,
    'LA': 8.8, 'SE': 6.7, 'NZ': 6.1, 'ET': 4.2,
  };

  static const double _goldSlope = 1.0; // per factor of 10 in tonnes
  static const double _goldMin = 0.5;
  static const double _goldMax = 3;

  static double _goldRate(double tonnes) {
    final r = (0.5 + _goldSlope * log(tonnes) / ln10).clamp(_goldMin, _goldMax);
    return (r * 100).round() / 100;
  }

  static final Map<String, TerritoryRule> _goldRules = {
    for (final e in _goldT.entries)
      e.key: TerritoryRule(rate: _goldRate(e.value)),
  };

  /// Income multiplier for a building in a territory with no rule of its own.
  /// Buildings not listed here default to 1.
  static const Map<String, double> defaultRate = {
    'gold_mine': 0.25,
  };

  /// building id -> groups of territories sharing one rule. Exact rules in
  /// [byBuilding] win over these.
  static const Map<String, List<_Group>> byGroup = {
  };

  static TerritoryRule? _find(String buildingId, String? territoryId) {
    if (territoryId == null) return null;
    final exact = byBuilding[buildingId]?[territoryId];
    if (exact != null) return exact;
    final groups = byGroup[buildingId];
    if (groups == null) return null;
    for (final g in groups) {
      if (g.ids.contains(territoryId)) return g.rule;
    }
    return null;
  }

  /// Income multiplier for [buildingId] in [territoryId] (1 if untouched).
  static double rateOf(String buildingId, String? territoryId) {
    if (territoryId == null) return 1;
    return _find(buildingId, territoryId)?.rate ??
        defaultRate[buildingId] ??
        1;
  }

  /// true / false to force availability, null to use the normal rules.
  static bool? allowedOf(String buildingId, String? territoryId) =>
      _find(buildingId, territoryId)?.allowed;
}