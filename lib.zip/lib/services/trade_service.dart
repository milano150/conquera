import 'package:cloud_firestore/cloud_firestore.dart';

import '../config/game_rules.dart';
import '../models/player_state.dart';
import '../models/trade_offer.dart';
import 'firestore_service.dart' show GameActionException;
import 'server_clock.dart';

/// Player-to-player trading: gold for territories, either way.
///
/// Offers live in games/{gameId}/trades/{offerId}. Accepting one is a single
/// transaction that moves the territory and the gold and fixes both players'
/// income. Only territories WITHOUT a building can be traded (so market /
/// refinery income never gets stale), and nobody can sell their last one.
/// Troops stay on the territory.
class TradeService {
  TradeService({FirebaseFirestore? firestore})
      : _db = firestore ?? FirebaseFirestore.instance;

  final FirebaseFirestore _db;

  static const int maxPrice = 1000000;

  DocumentReference<Map<String, dynamic>> _game(String g) =>
      _db.collection('games').doc(g);
  CollectionReference<Map<String, dynamic>> _offers(String g) =>
      _game(g).collection('trades');
  CollectionReference<Map<String, dynamic>> _provinces(String g) =>
      _game(g).collection('provinces');
  DocumentReference<Map<String, dynamic>> _player(String g, String uid) =>
      _game(g).collection('players').doc(uid);

  Stream<List<TradeOffer>> watchOffers({required String gameId}) => _offers(
        gameId,
      )
          .orderBy('createdAt', descending: true)
          .limit(150)
          .snapshots()
          .map((s) => [for (final d in s.docs) TradeOffer.fromDoc(d)]);

  bool _hasBuilding(Map<String, dynamic>? province) {
    final b = province?['building'];
    if (b is! Map) return false;
    final type = b['type'] as String? ?? 'none';
    return type.isNotEmpty && type != 'none';
  }

  int _owned(DocumentSnapshot<Map<String, dynamic>> snap) =>
      (snap.data()?['ownedCount'] as num?)?.toInt() ?? 0;

  double _income(DocumentSnapshot<Map<String, dynamic>> snap) =>
      (snap.data()?['buildingIncome'] as num?)?.toDouble() ?? 0;

  /// Same shape as FirestoreService._settledIncomeUpdate: gold is settled at
  /// the old rate (minus [spend]), then the new counts and rate are stored.
  Map<String, dynamic> _settled(
    DocumentSnapshot<Map<String, dynamic>> snap, {
    required int owned,
    required double income,
    required DateTime now,
    required double spend,
  }) {
    final territories = owned < 0 ? 0 : owned;
    final inc = income < 1e-9 ? 0.0 : income;
    return {
      'gold': PlayerState.fromDoc(snap).goldAt(now) - spend,
      'goldUpdatedAt': FieldValue.serverTimestamp(),
      'ownedCount': territories,
      'buildingIncome': inc,
      'goldRate':
          GameRules.incomeRate(territories: territories, buildingIncome: inc),
    };
  }

  Future<void> createOffer({
    required String gameId,
    required String uid,
    required TradeKind kind,
    required String provinceId,
    required int price,
  }) async {
    if (price < 1 || price > maxPrice) {
      throw const GameActionException('Price must be 1 to 1,000,000.');
    }
    final playerSnap = await _player(gameId, uid).get();
    final provinceSnap = await _provinces(gameId).doc(provinceId).get();
    if (!playerSnap.exists) throw const GameActionException('Player not found.');

    final data = provinceSnap.data();
    final owner = data?['ownerId'] as String?;
    if (_hasBuilding(data)) {
      throw const GameActionException("Territories with buildings can't be traded.");
    }
    if (kind == TradeKind.sell) {
      if (owner != uid) {
        throw const GameActionException("You don't own this territory.");
      }
      if (_owned(playerSnap) <= 1) {
        throw const GameActionException('Keep at least one territory.');
      }
    } else {
      if (owner == null || owner == uid) {
        throw const GameActionException('Pick a territory owned by another player.');
      }
      final gold = PlayerState.fromDoc(playerSnap).goldAt(ServerClock.now());
      if (gold < price) throw const GameActionException('Not enough gold.');
    }

    await _offers(gameId).add({
      'kind': kind == TradeKind.sell ? 'sell' : 'buy',
      'creatorId': uid,
      'creatorName': (playerSnap.data()?['displayName'] as String?) ?? 'Player',
      'creatorColor': (playerSnap.data()?['colorHex'] as String?) ?? '#457B9D',
      'provinceId': provinceId,
      'price': price,
      'createdAt': FieldValue.serverTimestamp(),
    });
  }

  Future<void> cancelOffer({
    required String gameId,
    required String uid,
    required String offerId,
  }) async {
    final ref = _offers(gameId).doc(offerId);
    final snap = await ref.get();
    if (snap.data()?['creatorId'] == uid) await ref.delete();
  }

  /// [uid] accepts an offer made by someone else. For a sell offer [uid]
  /// buys the territory; for a buy offer [uid] sells it.
  Future<void> acceptOffer({
    required String gameId,
    required String uid,
    required String offerId,
  }) async {
    final offerRef = _offers(gameId).doc(offerId);
    final pre = await offerRef.get();
    if (!pre.exists) throw const GameActionException('This offer is gone.');
    final provinceId = TradeOffer.fromDoc(pre).provinceId;
    final provinceRef = _provinces(gameId).doc(provinceId);

    // Markets saved this territory as a neighbor. Transactions can't run
    // queries, so find them first and re-read them inside.
    final marketDocs = await _provinces(gameId)
        .where('building.neighbors', arrayContains: provinceId)
        .get();
    final marketRefs = [for (final d in marketDocs.docs) d.reference];

    final error = await _db.runTransaction<String?>((tx) async {
      final offerSnap = await tx.get(offerRef);
      if (!offerSnap.exists) return 'This offer is gone.';
      final offer = TradeOffer.fromDoc(offerSnap);
      if (offer.provinceId != provinceId) return 'This offer changed. Try again.';
      if (offer.creatorId == uid) return 'That is your own offer.';

      final sell = offer.kind == TradeKind.sell;
      final buyerId = sell ? uid : offer.creatorId;
      final sellerId = sell ? offer.creatorId : uid;
      final buyerRef = _player(gameId, buyerId);
      final sellerRef = _player(gameId, sellerId);

      final provinceSnap = await tx.get(provinceRef);
      final buyerSnap = await tx.get(buyerRef);
      final sellerSnap = await tx.get(sellerRef);
      final markets = <DocumentSnapshot<Map<String, dynamic>>>[];
      for (final ref in marketRefs) {
        markets.add(await tx.get(ref));
      }

      final data = provinceSnap.data();
      if (!provinceSnap.exists ||
          data?['ownerId'] != sellerId ||
          _hasBuilding(data)) {
        tx.delete(offerRef);
        return 'This offer is no longer valid.';
      }
      if (!buyerSnap.exists || !sellerSnap.exists) {
        tx.delete(offerRef);
        return 'A player in this offer has left.';
      }
      if (_owned(sellerSnap) <= 1) {
        return 'The seller must keep at least one territory.';
      }
      final now = ServerClock.now();
      if (PlayerState.fromDoc(buyerSnap).goldAt(now) < offer.price) {
        return sell ? 'Not enough gold.' : 'The buyer can no longer afford this.';
      }

      // Markets next door trade with one more / one fewer territory.
      var gain = 0.0;
      var loss = 0.0;
      for (final snap in markets) {
        if (!snap.exists) continue;
        final m = snap.data();
        final b = m?['building'];
        if (b is! Map) continue;
        final neighbors = (b['neighbors'] as List?)?.cast<String>() ?? const [];
        if (!neighbors.contains(provinceId)) continue;
        final def = GameRules.buildingById(b['type'] as String? ?? '');
        if (def == null || !def.tradesWithNeighbors || def.suppliedBy.isNotEmpty) {
          continue;
        }
        final trades = (b['trades'] as num?)?.toInt() ?? 0;
        final owner = m?['ownerId'];
        if (owner == buyerId) {
          tx.update(snap.reference, {'building.trades': trades + 1});
          gain += def.partnerRateFor(snap.id);
        } else if (owner == sellerId && trades > 0) {
          tx.update(snap.reference, {'building.trades': trades - 1});
          loss += def.partnerRateFor(snap.id);
        }
      }

      tx.update(provinceRef, {'ownerId': buyerId});
      tx.delete(offerRef);
      tx.update(
        buyerRef,
        _settled(
          buyerSnap,
          owned: _owned(buyerSnap) + 1,
          income: _income(buyerSnap) + gain,
          now: now,
          spend: offer.price.toDouble(),
        ),
      );
      tx.update(
        sellerRef,
        _settled(
          sellerSnap,
          owned: _owned(sellerSnap) - 1,
          income: _income(sellerSnap) - loss,
          now: now,
          spend: -offer.price.toDouble(),
        ),
      );
      return null;
    });

    if (error != null) throw GameActionException(error);
  }
}