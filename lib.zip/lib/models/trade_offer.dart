import 'package:cloud_firestore/cloud_firestore.dart';

/// [sell]: the creator owns the territory and wants gold for it.
/// [buy]: the creator wants someone else's territory and offers gold.
enum TradeKind { sell, buy }

/// One open offer, read from games/{gameId}/trades/{offerId}.
class TradeOffer {
  final String id;
  final TradeKind kind;
  final String creatorId;
  final String creatorName;
  final String creatorColor;
  final String provinceId;
  final int price;
  final DateTime? createdAt;

  const TradeOffer({
    required this.id,
    required this.kind,
    required this.creatorId,
    required this.creatorName,
    required this.creatorColor,
    required this.provinceId,
    required this.price,
    this.createdAt,
  });

  factory TradeOffer.fromDoc(DocumentSnapshot<Map<String, dynamic>> doc) {
    final d = doc.data() ?? const <String, dynamic>{};
    final at = d['createdAt'];
    return TradeOffer(
      id: doc.id,
      kind: d['kind'] == 'buy' ? TradeKind.buy : TradeKind.sell,
      creatorId: (d['creatorId'] as String?) ?? '',
      creatorName: (d['creatorName'] as String?) ?? 'Player',
      creatorColor: (d['creatorColor'] as String?) ?? '#457B9D',
      provinceId: (d['provinceId'] as String?) ?? '',
      price: (d['price'] as num?)?.toInt() ?? 0,
      createdAt: at is Timestamp ? at.toDate() : null,
    );
  }
}