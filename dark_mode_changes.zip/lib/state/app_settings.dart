import 'package:flutter/widgets.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../theme/conquera_theme.dart';

/// Device-local app settings. Only dark mode for now.
class AppSettings {
  const AppSettings._();

  static const String _darkKey = 'dark_mode';

  static bool get darkMode => ConqueraColors.dark;

  /// Call once before runApp.
  static Future<void> load() async {
    final prefs = await SharedPreferences.getInstance();
    ConqueraColors.dark = prefs.getBool(_darkKey) ?? false;
  }

  static Future<void> setDarkMode(bool value) async {
    ConqueraColors.dark = value;
    // Colors are read from static getters, so force every widget (and
    // painter) to rebuild. State is kept, like a hot reload.
    await WidgetsBinding.instance.reassembleApplication();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_darkKey, value);
  }
}
