import 'package:flutter/material.dart';

import '../state/app_settings.dart';
import '../theme/conquera_theme.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  Future<void> _toggle(bool v) async {
    await AppSettings.setDarkMode(v);
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final dark = AppSettings.darkMode;
    return Scaffold(
      backgroundColor: ConqueraColors.land,
      appBar: AppBar(
        backgroundColor: ConqueraColors.surface,
        surfaceTintColor: Colors.transparent,
        elevation: 0,
        foregroundColor: ConqueraColors.ink,
        title: Text('Settings', style: ConqueraText.title.copyWith(fontSize: 20)),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Divider(height: 1, color: ConqueraColors.divider),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.symmetric(vertical: ConqueraSpace.sm),
        children: [
          InkWell(
            onTap: () => _toggle(!dark),
            child: Padding(
              padding: const EdgeInsets.symmetric(
                horizontal: ConqueraSpace.md,
                vertical: ConqueraSpace.sm,
              ),
              child: Row(
                children: [
                  Icon(
                    dark ? Icons.dark_mode_outlined : Icons.light_mode_outlined,
                    size: 20,
                    color: ConqueraColors.muted,
                  ),
                  const SizedBox(width: ConqueraSpace.md),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Dark mode', style: ConqueraText.name),
                        const SizedBox(height: 2),
                        Text(
                          dark ? 'On' : 'Off',
                          style: ConqueraText.label,
                        ),
                      ],
                    ),
                  ),
                  Switch(
                    value: dark,
                    onChanged: _toggle,
                    activeColor: ConqueraColors.accent,
                    activeTrackColor: ConqueraColors.accent.withAlpha(70),
                    inactiveThumbColor: ConqueraColors.muted,
                    inactiveTrackColor: Colors.transparent,
                    trackOutlineColor: MaterialStatePropertyAll(
                      dark ? ConqueraColors.accent : ConqueraColors.divider,
                    ),
                  ),
                ],
              ),
            ),
          ),
          Divider(height: 1, color: ConqueraColors.divider),
        ],
      ),
    );
  }
}
